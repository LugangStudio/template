<?php
define('APPNAME', 'ECTouch');
define('VERSION', '1.0');
define('RELEASE', '20141218');
define('ECTOUCH_AUTH_KEY', '');