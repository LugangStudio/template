<?php
return array(
    'APP_STATE' => 1,
    'APP_NAME' => 'ECTOUCH安装向导',
    'APP_VER' => '1.0.2014.0520',
    'APP_AUTHOR' => 'Carson',
    'APP_ORIGINAL_PREFIX' => '',
    'APP_TABLES' => '',

    'title' => 'ECTOUCH安装向导',
    'run_after_del' => false,
);
